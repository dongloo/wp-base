## Note for GIT
* Install npm -> `npm install`
* Run project -> `npm run dev` then go to 'http://localhost:[port]/src/index.html to view site'
* Watch tailwind to style.css -> `npx tailwindcss -i ./src/assets/vendors/tailwindcss/tailwindcss.css -o ./src/assets/css/style.css --watch`
* Custom css in `./src/assets/css/custom.css`
